#pragma once
#include <vector>
#include <algorithm>

using namespace std;

tuple<unsigned, unsigned, unsigned> getCriticalIndices(const vector<double>& valueCache)
{
	tuple<unsigned, unsigned, unsigned> result = { 0, 0, 0 };

	for(unsigned i = 1; i < valueCache.size(); i++)
	{
		if(valueCache[i] > valueCache[get<0>(result)])
		{
			get<1>(result) = get<0>(result);
			get<0>(result) = i;
		}
		else if(valueCache[i] > valueCache[get<1>(result)])
		{
			get<1>(result) = i;
		}

		if(valueCache[i] < valueCache[get<2>(result)])
		{
			get<2>(result) = i;
		}
	}

	return result;
}

template<typename FunctionType>
vector<double> nelderMeadMin(vector<vector<double>> simplexPoints, FunctionType& minFunction,
	double reflectionCoeff, double contractionCoeff, double expansionCoeff, double shrinkCoeff)
{
	/*class SimplexPointCompare
	{
	private:
		FunctionType& functionRef;
	public:
		SimplexPointCompare(FunctionType& functionRef):
			functionRef(functionRef)
		{}

		bool operator()(const vector<double>& point1, const vector<double>& point2) const
		{
			return (minFunction.evaluate(point1) < minFunction.evaluate(point2));
		}
	};*/

	/*struct SimplexPoint
	{
		vector<double> inputValues;
		double functionValue;

		bool operator<(const SimplexPoint& rhs)
		{
			return (this->functionValue < rhs.functionValue);
		}
	};

	vector<SimplexPoint> simplexPoints(initialSimplexPoints.size());

	for(unsigned i = 0; i < initialSimplexPoints.size(); i++)
	{
		simplexPoints[i] = { initialSimplexPoints[i], minFunction(initialSimplexPoints[i]) };
	}

	sort(simplexPoints.begin(), simplexPoints.end());*/

	const unsigned numInputComponents = simplexPoints[0].size();
	vector<double> functionCache(simplexPoints.size());

	for(unsigned i = 0; i < simplexPoints.size(); i++)
	{
		functionCache[i] = minFunction.evaluate(simplexPoints[i]);
	}

	do
	{
		vector<double> centroidInput(0.0, numInputComponents);
		
		for(unsigned i = 0; i < numInputComponents - 1; i++)
		{
			for(unsigned j = 0; j < simplexPoints.size(); j++)
			{
				centroidInput[i] += simplexPoints[j][i];
			}

			centroidInput[i] /= simplexPoints.size();
		}

		// Calculate the reflected point
		vector<double> reflectedPoint(0.0, numInputComponents);

		for(unsigned i = 0; i < numInputComponents; i++)
		{
			reflectedPoint[i] = centroidInput[i] + reflectionCoeff * (centroidInput[i] - )
		}
	}
	while (true);
}
