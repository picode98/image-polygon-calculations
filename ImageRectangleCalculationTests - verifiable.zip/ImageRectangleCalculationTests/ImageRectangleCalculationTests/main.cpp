#include <iostream>
#include <iomanip>
#include <vector>
// #include <algorithm>
#include <queue>
#include <optional>

using namespace std;

struct ParametricLine
{
	vector<double> cValues;

	vector<double> getCoords(double tValue) const
	{
		vector<double> resultVector = vector<double>(this->cValues.size());

		for (unsigned i = 0; i < this->cValues.size(); i++)
		{
			resultVector[i] = cValues[i] * tValue;
		}

		return resultVector;
	}
};

template<typename vectorType>
void printVector(const vector<vectorType>& values, ostream& outStream)
{
	outStream << "{";

		for (unsigned i = 0; i < values.size(); i++)
		{
			outStream << values[i];

			if (i < (values.size() - 1))
			{
				outStream << ' ';
			}
		}

	outStream << '}';
}

double pythagoreanDistance(const vector<double>& point1, const vector<double>& point2)
{
	double distValue = 0.0;

	for(unsigned i = 0; i < point1.size(); i++)
	{
		distValue += ((point1[i] - point2[i]) * (point1[i] - point2[i]));
	}

	return sqrt(distValue);
}

double vectorMagnitude(const vector<double>& values)
{
	double currentTotal = 0.0;

	for (double element : values)
	{
		currentTotal += (element * element);
	}

	return sqrt(currentTotal);
}

double polygonError(const vector<ParametricLine>& lineDefinitions,
					  const vector<double>& tValues, const vector<double>& expectedLengths)
{
	double totalError = 0.0;

	vector<vector<double>> pointValues(lineDefinitions.size());

	for(unsigned i = 0; i < lineDefinitions.size(); i++)
	{
		unsigned nextPointIndex = (i + 1) % lineDefinitions.size();

		pointValues[i] = lineDefinitions[i].getCoords(tValues[i]);
		pointValues[nextPointIndex] = lineDefinitions[nextPointIndex].getCoords(tValues[nextPointIndex]);

		double actualDistance = pythagoreanDistance(pointValues[i],
			pointValues[nextPointIndex]);

		totalError += abs(expectedLengths[i] - actualDistance);
	}

	// For testing only; implement more permanent solution if this works properly
	totalError += abs(pythagoreanDistance(pointValues[0], pointValues[2])
		- sqrt(expectedLengths[0] * expectedLengths[0] + expectedLengths[1] * expectedLengths[1]));

	totalError += abs(pythagoreanDistance(pointValues[1], pointValues[3])
		- sqrt(expectedLengths[1] * expectedLengths[1] + expectedLengths[2] * expectedLengths[2]));

	return totalError;
}

vector<double> polygonErrorGradient(const vector<ParametricLine>& lineDefinitions,
	vector<double> tValues, const vector<double>& expectedLengths, double offset)
{
	vector<double> gradientResult(lineDefinitions.size());

	for(unsigned i = 0; i < lineDefinitions.size(); i++)
	{
		double baseTValue = tValues[i];

		tValues[i] = (baseTValue - offset);
		double firstGradientPoint = polygonError(lineDefinitions, tValues, expectedLengths);

		tValues[i] = (baseTValue + offset);
		double secondGradientPoint = polygonError(lineDefinitions, tValues, expectedLengths);

		tValues[i] = baseTValue;

		gradientResult[i] = ((secondGradientPoint - firstGradientPoint) / (2.0 * offset));
	}

	return gradientResult;
}

optional<vector<double>> simplePolygonErrorMinimize(const vector<ParametricLine>& lineDefinitions,
	vector<double> tValues, const vector<double>& expectedLengths, double stepLength, double tolerance)
{
	const double gradientOffset = 1.0e-5;
	const unsigned historyLength = 51;

	vector<double> currentGradient;
	// vector<bool> reverseSwitches = vector<bool>(tValues.size());
	bool convergenceFailed = false;
	deque<vector<double>> tValueHistory;
	double gradientMagnitude, runningAverageSpeed;

	do
	{
		currentGradient = polygonErrorGradient(lineDefinitions, tValues, expectedLengths, gradientOffset);
		gradientMagnitude = vectorMagnitude(currentGradient);

		for(unsigned i = 0; i < currentGradient.size(); i++)
		{
			double tValueDelta = -(currentGradient[i] * stepLength / gradientMagnitude);

			/*if ((tValues[i] + tValueDelta) <= 0.0)
			{
				reverseSwitches[i] = true;
			}
			else if(reverseSwitches[i] && currentGradient[i] < 0.0)
			{
				reverseSwitches[i] = false;
				tValueDelta = (tValueDelta < 0.0 ? -1.0 : 1.0) * max(abs(tValueDelta), 16.0 * gradientOffset);
			}*/


			// tValues[i] += ((reverseSwitches[i] ? -1.0 : 1.0) * tValueDelta);
			tValues[i] += tValueDelta;

			if(tValues[i] < 0.0)
			{
				convergenceFailed = true;
			}
		}

		tValueHistory.push_back(tValues);

		if (tValueHistory.size() > historyLength)
		{
			tValueHistory.pop_front();
		}

		runningAverageSpeed = pythagoreanDistance(tValueHistory.front(), tValueHistory.back()) / (tValueHistory.size() * stepLength);

		
		//cout << "T-Values: ";
		//printVector(tValues, cout);

		///*
		//cout << " Reverse switches: ";
		//printVector(reverseSwitches, cout);
		//*/

		//cout << " Gradient magnitude: " << gradientMagnitude << " Total error: " << polygonError(lineDefinitions, tValues, expectedLengths)
		//	 << " Average speed: " << runningAverageSpeed << endl;
		
		
	} while ((tValueHistory.size() < historyLength || runningAverageSpeed > tolerance) && !convergenceFailed);

	if(convergenceFailed)
	{
		// cout << "Convergence failed." << endl;
		return optional<vector<double>>();
	}
	else
	{
		// cout << "Converged to ";
		// printVector(tValues, cout);
		// cout << endl;

		return tValues;
	}
}

/*
vector<double> simplePolygonErrorMinimize(const vector<ParametricLine>& lineDefinitions,
	const vector<double>& tValues, const vector<double>& expectedLengths, double minStep, double maxStep, double tolerance)
{
	const double stepFactor = 0.01;
	vector<double> currentResult = simplePolygonErrorMinimizeAux(lineDefinitions, tValues, expectedLengths, maxStep, tolerance);


}
*/

optional<vector<double>> findPolygonErrorGlobalMin(const vector<ParametricLine>& lineDefinitions, const vector<double>& expectedLengths,
										double minStep, double maxStep, double tolerance, double minT, double maxT, double tStep)
{
	vector<double> currentInitialTValues = vector<double>(lineDefinitions.size(), minT);
	optional<vector<double>> currentMinTValues = simplePolygonErrorMinimize(lineDefinitions, currentInitialTValues, expectedLengths, maxStep, tolerance);
	double currentMinError = numeric_limits<double>::max();

	const double stepFactor = 0.01;

	if (currentMinTValues.has_value())
	{
		currentMinError = polygonError(lineDefinitions, currentMinTValues.value(), expectedLengths);
	}

	for(unsigned index = 1; minT + index * tStep <= maxT; index++)
	{
		double currentT = minT + index * tStep;

		// cout << "Attempting coarse minimization with t = " << currentT << endl;

		for(double& thisElement : currentInitialTValues)
		{
			thisElement = currentT;
		}

		optional<vector<double>> currentTValues = simplePolygonErrorMinimize(lineDefinitions, currentInitialTValues, expectedLengths, maxStep, tolerance);

		if (currentTValues.has_value())
		{
			double currentError = polygonError(lineDefinitions, currentTValues.value(), expectedLengths);

			if (currentError < currentMinError)
			{
				currentMinTValues = currentTValues;
				currentMinError = currentError;
			}
		}
	}

	for(double currentStep = maxStep * stepFactor; currentStep > minStep && currentMinTValues.has_value(); currentStep *= stepFactor)
	{
		currentMinTValues = simplePolygonErrorMinimize(lineDefinitions, currentMinTValues.value(), expectedLengths, currentStep, tolerance);
	}

	if (currentMinTValues.has_value())
	{
		currentMinTValues = simplePolygonErrorMinimize(lineDefinitions, currentMinTValues.value(), expectedLengths, minStep, tolerance);
	}

	return currentMinTValues;
}

ParametricLine imageCoordToLine(unsigned xCoord, unsigned yCoord, unsigned imageWidth, unsigned imageHeight, double xFOV, double yFOV)
{
	double canvasWidth = 2.0 * tan(xFOV / 2.0),
		canvasHeight = 2.0 * tan(yFOV / 2.0);

	double xCanvas = (static_cast<double>(xCoord) / imageWidth) * canvasWidth - (canvasWidth / 2.0),
		   yCanvas = (canvasHeight / 2.0) - (static_cast<double>(yCoord) / imageHeight) * canvasHeight;

	return { {xCanvas, yCanvas, 1.0} };
}

int main()
{
	// cout << setprecision(numeric_limits<double>::digits10);

	vector<ParametricLine> testLines;

	const double testCameraXFOV = 0.95293483894741339867706675405904,
		testCameraYFOV = 0.65623979003061076816550159172411;

	const unsigned testCameraImgWidth = 2560,
				   testCameraImgHeight = 1440;

	//testLines.push_back({ {0.5092138563 / 5.0097276885, 2.9912999758 / 5.0097276885, 1.0} });
	//testLines.push_back({ {1.0 / 4.0, 1.0 / 4.0, 1.0} });
	//testLines.push_back({ {3.0 / 3.0, 2.0 / 3.0, 1.0} });
	//testLines.push_back({ {2.5092138563 / 4.0097276885, 3.9912999758 / 4.0097276885, 1.0} });
	testLines.push_back(imageCoordToLine(1114, 833, testCameraImgWidth, testCameraImgHeight, testCameraXFOV, testCameraYFOV));
	testLines.push_back(imageCoordToLine(1655, 602, testCameraImgWidth, testCameraImgHeight, testCameraXFOV, testCameraYFOV));
	testLines.push_back(imageCoordToLine(1852, 773, testCameraImgWidth, testCameraImgHeight, testCameraXFOV, testCameraYFOV));
	testLines.push_back(imageCoordToLine(1318, 1069, testCameraImgWidth, testCameraImgHeight, testCameraXFOV, testCameraYFOV));

	//vector<double> testTValues = { 0.1, 3.0, 10.4, 3.2 };
	vector<double> rectLengths = { 2.0, 0.75, 2.0, 0.75 };

	/*cout << "Error value: " << polygonError(testLines, testTValues, rectLengths) << endl;

	vector<double> testResult = simplePolygonErrorMinimize(testLines, testTValues, rectLengths, 0.1, 0.01);
	cout << "Second refinement:" << endl;
	testResult = simplePolygonErrorMinimize(testLines, testResult, rectLengths, 0.001, 0.01);*/

	// ParametricLine lineCalcTest = imageCoordToLine(300, 150, 600, 300, 1.0, 0.5);
	// printVector(lineCalcTest.cValues, cout);

	//cout << polygonError(testLines, { 11.0, 8.0, 8.0, 11.0 }, rectLengths) << endl;

	// simplePolygonErrorMinimize(testLines, )

	optional<vector<double>> testResult = findPolygonErrorGlobalMin(testLines, rectLengths, 0.001, 0.2, 0.02, 1.0, 10.0, 1.0);

	/*if (testResult.has_value())
	{
		cout << "Convergence result: ";
		printVector(testResult.value(), cout);
		cout << endl;

		cout << "Coordinates:" << endl;

		for (unsigned i = 0; i < testResult.value().size(); i++)
		{
			printVector(testLines[i].getCoords(testResult.value()[i]), cout);
			cout << endl;
		}

		cout << "Error value: " << polygonError(testLines, testResult.value(), rectLengths) << endl;
	}
	else
	{
		cout << "T-values failed to converge." << endl;
	}*/

	// system("pause");
}